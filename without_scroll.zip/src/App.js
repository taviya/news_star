import React, { Component } from 'react'
import NavBar from './Component/NavBar'
import News from './Component/News'
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";

export default class App extends Component {
  pageNumber = 15;
  render() {
    return (
      <>
      <Router>
        <NavBar />
        {/* <News pageSize={this.pageNumber} category='sports' country='in'/> */}

        <Routes>
          <Route exact  path="/" element={<News key="sports" pageSize={this.pageNumber} category='sports' country='in' />}></Route>
          <Route exact  path="/business" element={<News key="business" pageSize={this.pageNumber} category='business' country='in' />}></Route>
          <Route exact  path="/entertainment" element={<News key="entertainment" pageSize={this.pageNumber} category='entertainment' country='in' />}></Route>
          <Route exact  path="/general" element={<News key="general" pageSize={this.pageNumber} category='general' country='in' />}></Route>
          <Route exact  path="/health" element={<News key="health" pageSize={this.pageNumber} category='health' country='in' />}></Route>
          <Route exact  path="/science" element={<News key="science" pageSize={this.pageNumber} category='science' country='in' />}></Route>
          <Route exact  path="/sports" element={<News key="sports" pageSize={this.pageNumber} category='sports' country='in' />}></Route>
          <Route exact  path="/technology" element={<News key="technology" pageSize={this.pageNumber} category='technology' country='in' />}></Route>
        </Routes>
      </Router>
      </>
    )
  }
}
